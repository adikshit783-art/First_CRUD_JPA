package com.practice.jpa.First.Repo;

import com.practice.jpa.First.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface StudentRepo  extends JpaRepository<Student,Long> {

//    public Student SaveToDB(Student Studentrepo){
//        System.out.println("enter in repo");
//        Student s1 = new Student();
//        s1.setEmail("demoEmail");
//        s1.setRollno(22);
//        System.out.println("exit repo");
//        return s1 ;
//        }
}
