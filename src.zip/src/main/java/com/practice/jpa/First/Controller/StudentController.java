package com.practice.jpa.First.Controller;

import com.practice.jpa.First.Service.StudentService;
import com.practice.jpa.First.entity.Student;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Student")
public class StudentController {

    StudentService sr ;
    StudentController(StudentService sr1){
        this.sr = sr1 ;
    }

    @PostMapping("/Save")
    public ResponseEntity<Student> save(@RequestBody Student student){

        Student studentService = sr.Save(student);

        return ResponseEntity.ok(studentService);
    }
//    @GetMapping("/{Id}")
//    public Student GetStudent(@PathVariable int id){
//
//    }
}
