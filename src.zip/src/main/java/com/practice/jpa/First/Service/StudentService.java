package com.practice.jpa.First.Service;

import com.practice.jpa.First.Repo.StudentRepo;
import com.practice.jpa.First.entity.Student;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    StudentRepo sp ;

    StudentService(StudentRepo sp1){
        this.sp = sp1 ;
    }

    public Student Save(Student student){
        System.out.println("service method called");
        Student saveStudent = sp.save(student);
        System.out.println("service method exit");
        return saveStudent;
    }

}
